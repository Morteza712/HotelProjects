/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Morteza
 */
public class Rooms {
    
    private Integer ID;
    private String View;
    private String Bed;
    private Integer price;
    private String facilities;
    
    public Rooms(){
        
    }

    public Rooms(Integer ID, String View, String bed, Integer price, String facilities) {
        this.ID = ID;
        this.View = View;
        this.Bed = bed;
        this.price = price;
        this.facilities = facilities;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getView() {
        return View;
    }

    public void setView(String View) {
        this.View = View;
    }
    
    public String getBed() {
        return Bed;
    }

    public void setBed(String Bed) {
        this.Bed = Bed;
    }
    
    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }
    
    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }
    
    public static String LastID() {
        try {  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\roomsXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("room");
            Node node = nodeList.item((nodeList.getLength()) - 1); 
            if (node.getNodeType() == Node.ELEMENT_NODE) {  
                Element eElement = (Element) node;
                return eElement.getElementsByTagName("ID").item(0).getTextContent();
            }
        }   
        catch (Exception e) {
            return "";
        }
        return "";
    }
    
    public void addRoom(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\roomsXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("room");
            root.appendChild(nodeElement);
            
            Element eID = doc.createElement("ID");
            Element eView = doc.createElement("View");
            Element eBed = doc.createElement("Bed");
            Element ePrice = doc.createElement("price");
            Element eFacilities = doc.createElement("facilities");
            
            eID.appendChild(doc.createTextNode(this.ID.toString()));
            eView.appendChild(doc.createTextNode(this.View));
            eBed.appendChild(doc.createTextNode(this.Bed));
            ePrice.appendChild(doc.createTextNode(this.price.toString()));
            eFacilities.appendChild(doc.createTextNode(this.facilities));
            
            nodeElement.appendChild(eID);
            nodeElement.appendChild(eView);
            nodeElement.appendChild(eBed);
            nodeElement.appendChild(ePrice);
            nodeElement.appendChild(eFacilities);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
    
    public void editRoom(){
        try {
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\roomsXMLDocument.xml");  
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(file);
            NodeList employees = document.getElementsByTagName("customer");
            Element emp = null;
            emp = (Element) employees.item(0);
            Node View = emp.getElementsByTagName("View").item(0).getFirstChild();
            View.setNodeValue(this.View);
            Node Bed = emp.getElementsByTagName("Bed").item(0).getFirstChild();
            Bed.setNodeValue(this.Bed);
            Node price = emp.getElementsByTagName("price").item(0).getFirstChild();
            price.setNodeValue((Integer.toString(this.price)));
            Node facilities = emp.getElementsByTagName("facilities").item(0).getFirstChild();
            facilities.setNodeValue(this.facilities);
        }
        catch(Exception ex){
        }
    }
    
    public static List<Rooms> getRoomList() {
        List<Rooms> objects = new ArrayList<>();
        try{  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\roomsXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("room");  
            for (int itr = 0; itr < nodeList.getLength(); itr++) {  
                Node node = nodeList.item(itr); 
                if (node.getNodeType() == Node.ELEMENT_NODE) {  
                    Element eElement = (Element) node;
                    Rooms room = new Rooms();
                    Integer ID = Integer.parseInt(eElement.getElementsByTagName("ID").item(0).getTextContent());
                    String View = eElement.getElementsByTagName("View").item(0).getTextContent();
                    String Bed = eElement.getElementsByTagName("Bed").item(0).getTextContent();
                    Integer price = Integer.parseInt(eElement.getElementsByTagName("price").item(0).getTextContent());
                    String facilities = eElement.getElementsByTagName("facilities").item(0).getTextContent();
                    room.setID(ID);
                    room.setView(View);
                    room.setBed(Bed);
                    room.setPrice(price);
                    room.setFacilities(facilities);
                    objects.add(room);
                }  
            }
            return objects;
        }
        catch(Exception ex){
            return objects;
        }
    }
}
