/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Morteza
 */
public class RentRoom {
    
    private Integer customerID;
    private Integer roomID;
    private String entryDate;
    private Integer nights;
    
    public RentRoom(){
        
    }

    public RentRoom(Integer customerID, Integer roomID, String entryDate, Integer nights) {
        this.customerID = customerID;
        this.roomID = roomID;
        this.entryDate = entryDate;
        this.nights = nights;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        this.customerID = customerID;
    }

    public Integer getRoomID() {
        return roomID;
    }

    public void setRoomID(Integer roomID) {
        this.roomID = roomID;
    }
    
    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }
    
    public Integer getNights() {
        return nights;
    }

    public void setNights(Integer nights) {
        this.nights = nights;
    }
    
    public void Rent(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\rentXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("room");
            root.appendChild(nodeElement);
            
            Element eCustomerID = doc.createElement("customerID");
            Element eRoomID = doc.createElement("roomID");
            Element eEntryDate = doc.createElement("entryDate");
            Element eNights = doc.createElement("nights");
            
            eCustomerID.appendChild(doc.createTextNode(this.customerID.toString()));
            eRoomID.appendChild(doc.createTextNode(this.roomID.toString()));
            eEntryDate.appendChild(doc.createTextNode(this.entryDate));
            eNights.appendChild(doc.createTextNode(this.nights.toString()));
            
            nodeElement.appendChild(eCustomerID);
            nodeElement.appendChild(eRoomID);
            nodeElement.appendChild(eEntryDate);
            nodeElement.appendChild(eNights);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
}
