/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Morteza
 */
public class Customers {
    
    private Integer ID;
    private String name;
    private String family;
    private Integer phoneNo;
    private String address;
    
    public Customers(){
        
    }

    public Customers(Integer ID, String name, String family, Integer phoneNo, String address) {
        this.ID = ID;
        this.name = name;
        this.family = family;
        this.phoneNo = phoneNo;
        this.address = address;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }
    
    public Integer getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(Integer phoneNo) {
        this.phoneNo = phoneNo;
    }
    
    public String getaddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    public static String LastID() {
        try {  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\customersXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("customer");
            Node node = nodeList.item((nodeList.getLength()) - 1); 
            if (node.getNodeType() == Node.ELEMENT_NODE) {  
                Element eElement = (Element) node;
                return eElement.getElementsByTagName("ID").item(0).getTextContent();
            }
        }   
        catch (Exception e) {
            return "";
        }
        return "";
    }
    
    public void addCustomer(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\customersXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("customer");
            root.appendChild(nodeElement);
            
            Element eID = doc.createElement("ID");
            Element eName = doc.createElement("name");
            Element eFamily = doc.createElement("family");
            Element ePhone = doc.createElement("phone");
            Element eAddress = doc.createElement("address");
            
            eID.appendChild(doc.createTextNode(this.ID.toString()));
            eName.appendChild(doc.createTextNode(this.name));
            eFamily.appendChild(doc.createTextNode(this.family));
            ePhone.appendChild(doc.createTextNode(this.phoneNo.toString()));
            eAddress.appendChild(doc.createTextNode(this.address));
            
            nodeElement.appendChild(eID);
            nodeElement.appendChild(eName);
            nodeElement.appendChild(eFamily);
            nodeElement.appendChild(ePhone);
            nodeElement.appendChild(eAddress);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
    
    public void editCustomer(){
        try {
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\customersXMLDocument.xml");  
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(file);
            NodeList employees = document.getElementsByTagName("customer");
            Element emp = null;
            emp = (Element) employees.item(0);
            Node name = emp.getElementsByTagName("name").item(0).getFirstChild();
            name.setNodeValue(this.name);
            Node family = emp.getElementsByTagName("family").item(0).getFirstChild();
            family.setNodeValue(this.family);
            Node phone = emp.getElementsByTagName("phone").item(0).getFirstChild();
            phone.setNodeValue((Integer.toString(this.phoneNo)));
            Node address = emp.getElementsByTagName("address").item(0).getFirstChild();
            address.setNodeValue(this.address);
        }
        catch(Exception ex){
        }
    }
    
    public static List<Customers> getCustomerList() {
        List<Customers> objects = new ArrayList<>();
        try{  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\customersXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("customer");  
            for (int itr = 0; itr < nodeList.getLength(); itr++) {  
                Node node = nodeList.item(itr); 
                if (node.getNodeType() == Node.ELEMENT_NODE) {  
                    Element eElement = (Element) node;
                    Customers customer = new Customers();
                    Integer ID = Integer.parseInt(eElement.getElementsByTagName("ID").item(0).getTextContent());
                    String name = eElement.getElementsByTagName("name").item(0).getTextContent();
                    String family = eElement.getElementsByTagName("family").item(0).getTextContent();
                    Integer phone = Integer.parseInt(eElement.getElementsByTagName("phone").item(0).getTextContent());
                    String address = eElement.getElementsByTagName("address").item(0).getTextContent();
                    customer.setID(ID);
                    customer.setName(name);
                    customer.setFamily(family);
                    customer.setPhoneNo(phone);
                    customer.setAddress(address);
                    objects.add(customer);
                }  
            }
            return objects;
        }
        catch(Exception ex){
            return objects;
        }
    }
}
