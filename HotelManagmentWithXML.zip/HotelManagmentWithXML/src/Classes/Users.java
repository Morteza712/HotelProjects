/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Morteza
 */
public class Users {
    
    private String userName;
    private String password;
    private String role;
    
    public Users(){
        
    }

    public Users(String userName, String password, String role) {
        this.userName = userName;
        this.password = password;
        this.role = role;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    public static Boolean checkUsers(String userName, String password) {
        Boolean flag = false;
        try {  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\usersXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("user");  
            for (int itr = 0; itr < nodeList.getLength(); itr++) {  
                Node node = nodeList.item(itr); 
                if (node.getNodeType() == Node.ELEMENT_NODE) {  
                    Element eElement = (Element) node;
                    String tempUserName = eElement.getElementsByTagName("userName").item(0).getTextContent();
                    String tempPassword = eElement.getElementsByTagName("password").item(0).getTextContent();
                    if(tempUserName.equals(userName) && tempPassword.equals(password)){
                        flag = true;
                    }
                }  
            }  
        }   
        catch (Exception e) {
            flag = false;
        }
        return flag;
    }  
    
    public void addUser(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\usersXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("user");
            root.appendChild(nodeElement);
            
            Element eUserName = doc.createElement("userName");
            Element ePassword = doc.createElement("password");
            Element eRole = doc.createElement("role");
            
            eUserName.appendChild(doc.createTextNode(this.userName));
            ePassword.appendChild(doc.createTextNode(this.password));
            eRole.appendChild(doc.createTextNode(this.role));
            
            nodeElement.appendChild(eUserName);
            nodeElement.appendChild(ePassword);
            nodeElement.appendChild(eRole);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
    
    public static List<Users> getUserList() {
        List<Users> objects = new ArrayList<>();
        try{  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\usersXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("user");  
            for (int itr = 0; itr < nodeList.getLength(); itr++) {  
                Node node = nodeList.item(itr); 
                if (node.getNodeType() == Node.ELEMENT_NODE) {  
                    Element eElement = (Element) node;
                    Users user = new Users();
                    String userName = eElement.getElementsByTagName("userName").item(0).getTextContent();
                    String password = eElement.getElementsByTagName("password").item(0).getTextContent();
                    String role = eElement.getElementsByTagName("role").item(0).getTextContent();
                    user.setUserName(userName);
                    user.setPassword(password);
                    user.setRole(role);
                    objects.add(user);
                }  
            }
            return objects;
        }
        catch(Exception ex){
            return objects;
        }
    }
}
