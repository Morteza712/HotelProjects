/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Morteza
 */
public class Meal {
    
    private Integer customerID;
    private Integer foodID;
    private Integer number;
    
    public Meal(){
        
    }

    public Meal(Integer customerID, Integer foodID, Integer number) {
        this.customerID = customerID;
        this.foodID = foodID;
        this.number = number;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        this.customerID = customerID;
    }

    public Integer getFoodID() {
        return foodID;
    }

    public void setFoodID(Integer foodID) {
        this.foodID = foodID;
    }
    
    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
    
    public void order(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\mealXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("food");
            root.appendChild(nodeElement);
            
            Element eCustomerID = doc.createElement("customerID");
            Element eFoodID = doc.createElement("foodID");
            Element eNumber = doc.createElement("number");
            
            eCustomerID.appendChild(doc.createTextNode(this.customerID.toString()));
            eFoodID.appendChild(doc.createTextNode(this.foodID.toString()));
            eNumber.appendChild(doc.createTextNode(this.number.toString()));
            
            nodeElement.appendChild(eCustomerID);
            nodeElement.appendChild(eFoodID);
            nodeElement.appendChild(eNumber);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
}
