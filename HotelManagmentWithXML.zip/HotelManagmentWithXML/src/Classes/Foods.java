/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Morteza
 */
public class Foods {
    
    private Integer ID;
    private String name;
    private String category;
    private Integer price;
    
    public Foods(){
        
    }

    public Foods(Integer ID, String name, String category, Integer price) {
        this.ID = ID;
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }
    
    public static String LastID() {
        try {  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\foodsXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("food");
            Node node = nodeList.item((nodeList.getLength()) - 1); 
            if (node.getNodeType() == Node.ELEMENT_NODE) {  
                Element eElement = (Element) node;
                return eElement.getElementsByTagName("ID").item(0).getTextContent();
            }
        }   
        catch (Exception e) {
            return "";
        }
        return "";
    }
    
    public void addFood(){
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\foodsXMLDocument.xml");  
            Document doc = db.parse(file);
            doc.normalize();
            Element root = doc.getDocumentElement();
            Element nodeElement = doc.createElement("food");
            root.appendChild(nodeElement);
            
            Element eID = doc.createElement("ID");
            Element eName = doc.createElement("name");
            Element eCategory = doc.createElement("category");
            Element ePrice = doc.createElement("price");
            
            eID.appendChild(doc.createTextNode(this.ID.toString()));
            eName.appendChild(doc.createTextNode(this.name));
            eCategory.appendChild(doc.createTextNode(this.category));
            ePrice.appendChild(doc.createTextNode(this.price.toString()));
            
            nodeElement.appendChild(eID);
            nodeElement.appendChild(eName);
            nodeElement.appendChild(eCategory);
            nodeElement.appendChild(ePrice);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
        }
        catch(Exception ex){
        }   
    }
    
    public void editFood(){
        try {
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\foodsXMLDocument.xml");  
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(file);
            NodeList employees = document.getElementsByTagName("customer");
            Element emp = null;
            emp = (Element) employees.item(0);
            Node name = emp.getElementsByTagName("name").item(0).getFirstChild();
            name.setNodeValue(this.name);
            Node category = emp.getElementsByTagName("category").item(0).getFirstChild();
            category.setNodeValue(this.category);
            Node price = emp.getElementsByTagName("price").item(0).getFirstChild();
            price.setNodeValue((Integer.toString(this.price)));
        }
        catch(Exception ex){
        }
    }
    
    public static List<Foods> getFoodList() {
        List<Foods> objects = new ArrayList<>();
        try{  
            File file = new File("E:\\My Files\\Wekerle - Helix\\Backend\\HotelManagmentWithXML\\src\\XML\\foodsXMLDocument.xml");  
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            Document doc = db.parse(file);  
            NodeList nodeList = doc.getElementsByTagName("food");  
            for (int itr = 0; itr < nodeList.getLength(); itr++) {  
                Node node = nodeList.item(itr); 
                if (node.getNodeType() == Node.ELEMENT_NODE) {  
                    Element eElement = (Element) node;
                    Foods food = new Foods();
                    Integer ID = Integer.parseInt(eElement.getElementsByTagName("ID").item(0).getTextContent());
                    String name = eElement.getElementsByTagName("name").item(0).getTextContent();
                    String category = eElement.getElementsByTagName("category").item(0).getTextContent();
                    Integer price = Integer.parseInt(eElement.getElementsByTagName("price").item(0).getTextContent());
                    food.setID(ID);
                    food.setName(name);
                    food.setCategory(category);
                    food.setPrice(price);
                    objects.add(food);
                }  
            }
            return objects;
        }
        catch(Exception ex){
            return objects;
        }
    }
}
